import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;


public class Robot {
	/** constante pour la port�e du radar */
	  public static final int PORTEE_RADAR = 3;
	/**
	 * image qui repr�sente le Robot
	 */
	private BufferedImage image;
	/**
	 * num�ro de la ligne courante du Robot (commence � 0)
	 */
	private int ligne;
	/**
	 * num�ro de la colonne courante du Robot (commence � 0)
	 */
	private int colonne;
	/**
	 * direction courante du Robot : "ouest", "est", "nord" ou "sud"
	 */
	private String direction;
	/**
	 * Terrain sur lequel se trouve le robot
	 */
	private Terrain t;
	/**
	 * Vitesse de d�placement du Robot (unit� : cases par seconde, ie m/s)
	 */
	private double vitesse = 2;
	/**
	 * Indique si le robot est d�truit ou non, un robot d�truit ne peut plus se
	 * d�placer
	 */
	private boolean robotDetruit = false;
	/**
	 * Indique la couleur de trac�
	 */
	private int trace = 0;

	/**
	 * Constructeur du Robot
	 * 
	 * @param ligne
	 *            ligne initiale du Robot (commence � 0)
	 * @param colonne
	 *            colonne initiale du Robot (commence � 0)
	 * @param direction
	 *            direction initiale du Robot (est, ouest, nord ou sud)
	 */
	public Robot(int ligne, int colonne, String direction) {
		// initialisation des attributs de la classe
		this.ligne = ligne;
		this.colonne = colonne;
		this.direction = direction;
		// initialisation de l'attribut image � partir d'un fichier de type
		// image repr�sentant le Robot � l'�cran


		try {
			image = ImageIO.read(new File("./data/robot.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	/**
	 * Permet de d�ssiner le robot � l'�cran
	 * 
	 * @param g
	 *            objet Graphics sur lequel on dessine le robot
	 * @param largeurCase
	 *            largeur de la case sur laquelle on va dessiner le robot (en
	 *            pixel). L'image sera automatiquement redimmensionn�e.
	 * @param hauteurCase
	 *            hauteur de la case sur laquelle on va dessiner le robot (en
	 *            pixel) L'image sera automatiquement redimmensionn�e.
	 */
	public void dessiner(Graphics g, int largeurCase, int hauteurCase) {
		// on convertit l'objet Graphics en Graphics2D afin de pouvoir utiliser
		// des m�thodes plus pratiques
		Graphics2D g2 = (Graphics2D) g;
		// on trouve l'angle de rotation de l'image en s'appuyant sur la
		// direction du Robot
		double angleRotation = 0;
		if ("est".equals(direction))
			angleRotation = Math.PI / 2;
		else if ("sud".equals(direction))
			angleRotation = Math.PI;
		else if ("ouest".equals(direction))
			angleRotation = 3 * Math.PI / 2;

		// on fait pivoter l'image de angleRotation, le centre de rotation �tant
		// le centre de la case
		g2.rotate(angleRotation, largeurCase / 2, hauteurCase / 2);
		// on dessine l'image pivot�e sur la case dont on connait le Graphics
		g2.drawImage(image, 0, 0, largeurCase, hauteurCase, null);
		// on remet la rotation � 0
		g2.rotate(-angleRotation, largeurCase / 2, hauteurCase / 2);

	}

	/**
	 * permet d'avancer le robot droit devant lui
	 * 
	 * @return 1 si le robot a pu avancer
	 * @return -1 si le robot n'a pas pu avancer � cause d'un obstacle ou des
	 *         limites du terrain
	 * @return -2 si le robot n'a pas pu avancer car il est d�truit
	 * @return -3 si le robot n'a plus de batterie
	 */
	public int avancer() {
		int retour = 1;


		// si le robot est d�truit on ne peut pas avancer
		if (robotDetruit)
			retour = -2;

		else
		// si on avance alors qu'il y a un obstacle devant alors on d�truit le
		// robot
		if (isObstacleDevant()) {

			detruireRobot();
			retour = -1;
		} else {
			// on peut faire avancer le robot suivant sa direction
			if ("nord".equals(direction)) {
				ligne--;
				
			} else if ("sud".equals(direction)) {
				ligne++;
				
			} else if ("ouest".equals(direction)) {
				colonne--;
								
			} else if ("est".equals(direction)) {
				colonne++;
				
			} else
				retour = -1;


			// on m�morise que la case est maintenant visit�e
			if(trace == 1){
				t.getGrille()[ligne][colonne].setBackground(Color.RED);
				t.getGrille()[ligne][colonne].setVisitee(true);
			}
			if(trace == 2){
				t.getGrille()[ligne][colonne].setBackground(Color.BLUE);
				t.getGrille()[ligne][colonne].setVisitee(true);
			}


		// on redessine le terrain
		t.repaint();

		// on effectue une petite pause fonction de la vitesse du robot
		try {
			Thread.sleep((int) (1000 / vitesse));
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		
	}
	return retour;
}



	/**
	 * Permet de faire reculer le robot
	 * 
	 * @return 1 si le robot a pu reculer
	 * @return -1 si le robot n'a pas pu reculer � cause d'un obstacle ou des
	 *         limites du terrain
	 * @return -2 si le robot n'a pas pu reculer car il est d�truit
	 * @return -3 si le robot n'a plus de batterie
	 */
	public int reculer() {
		int retour = 1;


		// si le robot est d�truit on ne peut pas avancer
		if (robotDetruit)
			retour = -2;
		else
		// si on recule alors qu'il y a un obstacle derriere alors on d�truit le
		// robot
		if (isObstacleDerriere()) {
			detruireRobot();
			retour = -1;
		}

		else {
			// on peut faire reculer le robot suivant sa direction oppos�e
			if ("sud".equals(direction)) {
				ligne--;
			} else if ("nord".equals(direction)) {
				ligne++;
			} else if ("est".equals(direction)) {
				colonne--;
			} else if ("ouest".equals(direction)) {
				colonne++;
			} else
				retour = -1;

			if(trace == 1){
				t.getGrille()[ligne][colonne].setBackground(Color.RED);
				t.getGrille()[ligne][colonne].setVisitee(true);
			}
			if(trace == 2){
				t.getGrille()[ligne][colonne].setBackground(Color.BLUE);
				t.getGrille()[ligne][colonne].setVisitee(true);
			}
		}
		// on redessine le terrain
		t.repaint();
		// on effectue une petite pause fonction de la vitesse du robot
		try {
			Thread.sleep((int) (1000 / vitesse));
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		return retour;
	}

	/**
	 * Permet de faire pivoter le robot sur sa droite
	 * 
	 * @return 1 si le robot a pu tourner correctement
	 * @return -2 si le robot n'a pas pu tourner car il est d�truit
	 * @return -3 si le robot n'a plus de batterie
	 */
	public int tournerDroite() {
		int retour = 1;

		if (robotDetruit)
			retour = -2;
		else {
			// on peut faire tourner le robot vers la droite
			if ("sud".equals(direction)) {
				direction = "ouest";
			} else if ("nord".equals(direction)) {
				direction = "est";
			} else if ("est".equals(direction)) {
				direction = "sud";
			} else if ("ouest".equals(direction)) {
				direction = "nord";
			}
		}
		// on redessine le terrain
		t.repaint();
		// on effectue une petite pause fonction de la vitesse du robot
		try {
			Thread.sleep((int) (1000 / vitesse));
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		return retour;
	}

	/**
	 * Permet de faire pivoter le robot sur sa droite
	 * 
	 * @return 1 si le robot a pu tourner correctement
	 * @return -2 si le robot n'a pas pu tourner car il est d�truit
	 * @return -3 si le robot n'a plus de batterie
	 */
	public int tournerGauche() {
		int retour = 1;

		if (robotDetruit)
			retour = -2;
		else {
			// on peut faire tourner le robot vers la gauche
			if ("sud".equals(direction)) {
				direction = "est";
			} else if ("nord".equals(direction)) {
				direction = "ouest";
			} else if ("est".equals(direction)) {
				direction = "nord";
			} else if ("ouest".equals(direction)) {
				direction = "sud";
			}
		}

		// on redessine le terrain
		t.repaint();
		// on effectue une petite pause fonction de la vitesse du robot
		try {
			Thread.sleep((int) (1000 / vitesse));
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		return retour;
	}

	/**
	 * 
	 * @param utiliseBatterie
	 *            true si la batterie est utilis�e pour la d�tection
	 * @return true si un obstacle est pr�sent devant le robot (le contours du
	 *         terrain est consid�r� comme un obstacle)
	 * @return false si aucun obstacle n'est pr�sent devant le robot
	 */

	public boolean isObstacleDevant() {



		// en fonction de la direction du robot, on teste s'il ne sort pas des
		// limites du terrain, et si la case devant lui n'est pas de type
		// Obstacle
		if ("nord".equals(direction) && ligne > 0
				&& !(t.getGrille()[ligne - 1][colonne] instanceof Obstacle))
			return false;
		else if ("sud".equals(direction) && ligne < t.getNbLignes() - 1
				&& !(t.getGrille()[ligne + 1][colonne] instanceof Obstacle))
			return false;
		else if ("ouest".equals(direction) && colonne > 0
				&& !(t.getGrille()[ligne][colonne - 1] instanceof Obstacle))
			return false;
		else if ("est".equals(direction) && colonne < t.getNbColonnes() - 1
				&& !(t.getGrille()[ligne][colonne + 1] instanceof Obstacle))
			return false;
		else
			return true;

	}

	/**
	 * Teste la pr�sence d'un obstacle � l'arri�re le Robot
	 * 
	 * @return true si un obstacle est pr�sent derri�re le robot
	 * @return false si aucun obstacle n'est pr�sent derri�re le robot
	 */
	public boolean isObstacleDerriere() {



		// en fonction de la direction du robot, on teste s'il ne sort pas des
		// limites du terrain, et si la case derri�re lui n'est pas de type
		// Obstacle
		if ("sud".equals(direction) && ligne > 0
				&& !(t.getGrille()[ligne - 1][colonne] instanceof Obstacle))
			return false;
		else if ("nord".equals(direction) && ligne < t.getNbLignes() - 1
				&& !(t.getGrille()[ligne + 1][colonne] instanceof Obstacle))
			return false;
		else if ("est".equals(direction) && colonne > 0
				&& !(t.getGrille()[ligne][colonne - 1] instanceof Obstacle))
			return false;
		else if ("ouest".equals(direction) && colonne < t.getNbColonnes() - 1
				&& !(t.getGrille()[ligne][colonne + 1] instanceof Obstacle))
			return false;

		else
			return true;

	}

	/**
	 * Permet de d�truire le robot
	 */
	public void detruireRobot() {
		// on indique que le robot est d�truit
		robotDetruit = true;
		// on modifie son image pour voir une image de robot d�truit
		try {
			image = ImageIO.read(new File("./data/robot_detruit.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		// on redessine le terrain
		t.repaint();
		System.out.println("Robot D�truit !");
	}

	/**
	 * Permet de savoir si le roboto se trouve sur une case victime
	 * 
	 * @return true si le robot se trouve sur une case victime
	 * @return false si le robot ne se trouve pas sur une case victime
	 */
	public boolean isSurVictime() {
		// on teste le type de la case du robot
		if (t.getGrille()[ligne][colonne] instanceof CaseVictime) {
			return true;
		} else
			return false;

	}

	/**
	 * Permet de sauver une victime, i.e. changer son �tat
	 * 
	 * @return 1 si la victime a �t� sauv�e
	 * @return -1 si aucune victime sur la case courante du robot
	 */
	public int sauverVictime() {
		// si la case courante est de type victime
		if (t.getGrille()[ligne][colonne] instanceof CaseVictime) {
			// on sauve la victime
			((CaseVictime) t.getGrille()[ligne][colonne]).sauverVictime();
			return 1;
		} else
			return -1;

	}


	/**
	 * getter de l'attribut vitesse
	 * 
	 * @return l'attribut vitesse
	 */
	public double getVitesse() {
		return vitesse;
	}

	/**
	 * setter de l'attribut vitesse
	 */
	public void setVitesse(double vitesse) {
		this.vitesse = vitesse;
	}

	/**
	 * getter de l'attribut ligne
	 * 
	 * @return l'attribut ligne
	 */
	public int getLigne() {
		return ligne;
	}

	/**
	 * getter de l'attribut colonne
	 * 
	 * @return l'attribut colonne
	 */
	public int getColonne() {
		return colonne;
	}

	/**
	 * getter de l'attribut direction
	 * 
	 * @return l'attribut direction
	 */
	public String getDirection() {
		return direction;
	}

	/**
	 * getter de l'attribut t
	 * 
	 * @return l'attribut t
	 */
	public Terrain getT() {
		return t;
	}

	/**
	 * setter de l'attribut t
	 */
	public void setT(Terrain t) {
		this.t = t;
	}

	/**
	 * M�thode permettant de modifier la couleur de tracer
	 * @param trace correspond au code de couleur :
	 * 1 pour le rouge,
	 * 2 pour le bleu.
	 */
	public void tracer(int trace){
		this.trace = trace;
		if(trace == 1){
			t.getGrille()[ligne][colonne].setBackground(Color.RED);
			t.getGrille()[ligne][colonne].setVisitee(true);
		}
		if(trace == 2){
			t.getGrille()[ligne][colonne].setBackground(Color.BLUE);
			t.getGrille()[ligne][colonne].setVisitee(true);
		}
			
	}
	
	/**
	 * radarAt renvoie le contenu d'une case � condition qu'elle soit � port�e du radar
	 *  @param ligne indisque le N� de ligne de la case recherch�e
  	 *  @param col indique le N� de colonne de la case recherch�e
  	 *  @return le contenu sous la forme d'un entier
  	 *  -100 si le cas n'est pas pr�vu
  	 *  -3 si la case n'existe pas
  	 *  -2 si elle contient le robot
  	 *  -1 si la case est trop loin du radar,
  	 *  0 si la case est vide,
  	 *  1 si la case contient la victime,
  	 *  2 si la case contient un obstacle,
	 */
	
	public int radarAt(int ligne, int col){
		//si les coordonn�es sortent du terrain on renvoie -3
		if ((ligne<0)||(ligne>=t.getNbLignes())||(col<0)||(col>=t.getNbColonnes()))
				return -3;
		//si les coordonn�es sont celles du robot on renvoie -2
		if (this.ligne==ligne && this.colonne==col)
			return -2;
		//si les coordonn�es sont trop �loign�es on renvoie -1
		if (Math.abs(this.ligne-ligne)>PORTEE_RADAR)
			return -1;
		if (Math.abs(this.colonne-col)>PORTEE_RADAR)
			return -1;	
		//sinon on analyse la case
		// attention ne fonctionne qu'� partir de JAVA 7
		// en JAVA <=6 il faut un if ou cr�er un enum
		String typ= t.getGrille()[ligne][col].getClass().getName();
		switch(typ){
		case "CaseVide":
		case "CaseDepart":
			return 0; //pas besoin de break car return quitte la m�thode
		case "CaseVictime":
			return 1;
		case "Obstacle":
			return 2;
		default:
			//si on arrive ici, c'est qu'une case non pr�vue par le radar est d�tect�e. 
			//Il convient d'ajouter le case au switch 
			System.out.println("Cas non pr�vu ! modifier la m�thode radarAt !");
			return -100;
		}
	
	}

}