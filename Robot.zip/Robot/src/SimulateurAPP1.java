/**
 * Programme principal avec la m�thode main
 * 
 * @author D�partement TIC - ESIGELEC
 * @version 2.0
 */
public class SimulateurAPP1 {

	public static void main(String[] args) {
		// cr�ation de l'environnement et r�cup�ration du terrain
		Terrain t = Environnement.creerEnvironnement(10,10);
		
		// creation du robot
		Robot robot = new Robot(0, 0, "est");
		// ajout du robot sur le terrain
		t.ajouterRobot(robot);

		//met � jour les composants graphiques
		t.updateIHM();

		// d�placement du robot
		robot.avancer();
		robot.avancer();
		// rotation du robot		
		robot.tournerDroite();
		
		robot.avancer();
			
	}

}